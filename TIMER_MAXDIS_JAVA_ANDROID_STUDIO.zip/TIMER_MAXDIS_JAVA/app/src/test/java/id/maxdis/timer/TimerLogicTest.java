package id.maxdis.timer;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Arrays;

public class TimerLogicTest {
    @Test public void originalPerLorongFormulaIsPreserved() {
        assertEquals(5L, TimerLogic.durationSeconds(1));
        assertEquals(60L, TimerLogic.durationSeconds(12));
        assertEquals(65L, TimerLogic.durationSeconds(13));
        assertEquals(300L, TimerLogic.durationSeconds(60));
    }

    @Test public void originalSessionTargetFormulaIsPreserved() {
        assertEquals(60.0, TimerLogic.targetSeconds(12), 0.0001);
        assertEquals(360.0, TimerLogic.targetSeconds(72), 0.0001);
        assertEquals(0.0, TimerLogic.targetSeconds(0), 0.0001);
    }

    @Test public void summaryIncludesWorkGapActualAndDeviation() {
        TimerLogic.Summary s = TimerLogic.summarize(Arrays.asList(
                new TimerLogic.Record(0, 12, 1_000L, 61_000L),
                new TimerLogic.Record(1, 12, 91_000L, 151_000L)
        ));
        assertEquals(24L, s.totalQty);
        assertEquals(120.0, s.workSeconds, 0.0001);
        assertEquals(30.0, s.gapSeconds, 0.0001);
        assertEquals(150.0, s.actualSeconds, 0.0001);
        assertEquals(120.0, s.targetSeconds, 0.0001);
        assertEquals(25.0, s.deviation, 0.0001);
        assertEquals("slow", s.type);
    }

    @Test public void formatDurationKeepsOriginalDisplayShape() {
        assertEquals("00:00", TimerLogic.formatDuration(0));
        assertEquals("01:05", TimerLogic.formatDuration(65));
        assertEquals("01:01:01", TimerLogic.formatDuration(3661));
    }
}
