package id.maxdis.timer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (TimerState.isRunning(context) || TimerState.isFinished(context)) {
            TimerService.start(context, TimerService.ACTION_RESTORE);
        }
    }
}
