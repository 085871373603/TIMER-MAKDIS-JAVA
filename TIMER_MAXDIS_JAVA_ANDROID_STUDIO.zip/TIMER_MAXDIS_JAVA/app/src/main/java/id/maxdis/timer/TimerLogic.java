package id.maxdis.timer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Pure calculation layer matching the original TIMER MAXDIS HTML formulas. */
public final class TimerLogic {
    private TimerLogic() {}

    public static final String[] CODES = {"L01", "L02", "L03", "L04", "L05", "L06"};
    public static final String[] NAMES = {"LORONG 1", "LORONG 2", "LORONG 3", "LORONG 4", "LORONG 5", "LORONG 6"};

    /** Original formula: ceil((Qty / 12) * 60 seconds). */
    public static long durationSeconds(long qty) {
        if (qty <= 0) throw new IllegalArgumentException("Qty harus lebih dari 0");
        return (long) Math.ceil((qty / 12.0) * 60.0);
    }

    /** Original session standard: (totalQty / 60) * 5 * 60 seconds. */
    public static double targetSeconds(long totalQty) {
        if (totalQty <= 0) return 0;
        return (totalQty / 60.0) * 5.0 * 60.0;
    }

    public static String formatDuration(double rawSeconds) {
        long total = Math.max(0L, Math.round(Double.isFinite(rawSeconds) ? rawSeconds : 0));
        long hours = total / 3600;
        long minutes = (total % 3600) / 60;
        long seconds = total % 60;
        if (hours > 0) return two(hours) + ":" + two(minutes) + ":" + two(seconds);
        return two(minutes) + ":" + two(seconds);
    }

    private static String two(long value) {
        return value < 10 ? "0" + value : String.valueOf(value);
    }

    public static String getShift(long timestampMillis) {
        java.util.Calendar calendar = java.util.Calendar.getInstance();
        calendar.setTimeInMillis(timestampMillis);
        int hour = calendar.get(java.util.Calendar.HOUR_OF_DAY);
        if (hour >= 2 && hour < 6) return "SHIFT 3";
        if (hour >= 9 && hour < 16) return "SHIFT 1";
        if (hour >= 21 && hour < 24) return "SHIFT 2";
        return "DI LUAR SHIFT";
    }

    public static Summary summarize(List<Record> source) {
        List<Record> records = new ArrayList<>(source);
        records.sort(Comparator.comparingInt(a -> a.index));
        Summary s = new Summary();
        if (records.isEmpty()) return s;

        for (Record r : records) {
            s.totalQty += r.qty;
            if (r.finish > r.start) s.workSeconds += (r.finish - r.start) / 1000.0;
        }

        for (int i = 1; i < records.size(); i++) {
            long gap = records.get(i).start - records.get(i - 1).finish;
            if (gap > 0) s.gapSeconds += gap / 1000.0;
        }

        long firstStart = records.get(0).start;
        long lastFinish = records.get(records.size() - 1).finish;
        s.actualSeconds = lastFinish >= firstStart ? (lastFinish - firstStart) / 1000.0 : 0;
        s.targetSeconds = targetSeconds(s.totalQty);
        s.startTimestamp = firstStart;
        s.finishTimestamp = lastFinish;

        if (s.targetSeconds > 0) {
            s.deviation = ((s.actualSeconds - s.targetSeconds) / s.targetSeconds) * 100.0;
            if (s.deviation < -10.0) {
                s.type = "fast";
                s.statusText = "DISPLAY TERLALU CEPAT";
            } else if (s.deviation <= 10.0) {
                s.type = "good";
                s.statusText = "BAGUS, DISPLAY TEPAT WAKTU";
            } else {
                s.type = "slow";
                s.statusText = "DISPLAY TERLALU LAMA";
            }
        } else {
            s.type = "good";
            s.statusText = "DATA WAKTU BELUM CUKUP";
        }
        return s;
    }

    public static final class Record {
        public final int index;
        public final long qty;
        public final long start;
        public final long finish;
        public Record(int index, long qty, long start, long finish) {
            this.index = index;
            this.qty = qty;
            this.start = start;
            this.finish = finish;
        }
    }

    public static final class Summary {
        public long totalQty;
        public double targetSeconds;
        public double workSeconds;
        public double gapSeconds;
        public double actualSeconds;
        public double deviation;
        public long startTimestamp;
        public long finishTimestamp;
        public String type = "good";
        public String statusText = "DATA WAKTU BELUM CUKUP";
    }
}
