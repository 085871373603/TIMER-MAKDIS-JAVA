package id.maxdis.timer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        TimerService.start(context, TimerService.ACTION_FINISH);
    }
}
