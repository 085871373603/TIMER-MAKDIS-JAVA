package id.maxdis.timer;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;

public class TimerService extends Service {
    public static final String ACTION_SYNC = "id.maxdis.timer.ACTION_SYNC";
    public static final String ACTION_FINISH = "id.maxdis.timer.ACTION_FINISH";
    public static final String ACTION_NEXT = "id.maxdis.timer.ACTION_NEXT";
    public static final String ACTION_RESTORE = "id.maxdis.timer.ACTION_RESTORE";

    private static final int NOTIFICATION_ID = 4201;
    private static final String CHANNEL_RUNNING = "maxdis_running_v1";
    private static final String CHANNEL_ALARM = "maxdis_alarm_v1";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer alarmPlayer;
    private long lastNotificationSecond = Long.MIN_VALUE;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (TimerState.isRunning(TimerService.this)) {
                long remaining = TimerState.endEpoch(TimerService.this) - System.currentTimeMillis();
                if (remaining <= 0) {
                    completeTimer();
                    return;
                }
                long seconds = (remaining + 999L) / 1000L;
                if (seconds != lastNotificationSecond) {
                    lastNotificationSecond = seconds;
                    updateNotification(false);
                }
                handler.postDelayed(this, 500L);
            } else if (TimerState.isFinished(TimerService.this)) {
                updateNotification(true);
                handler.postDelayed(this, 3000L);
            }
        }
    };

    public static void start(Context context, String action) {
        Intent intent = new Intent(context, TimerService.class);
        intent.setAction(action);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent);
        else context.startService(intent);
    }

    public static void createChannels(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel running = new NotificationChannel(
                CHANNEL_RUNNING, "Timer berjalan", NotificationManager.IMPORTANCE_LOW);
        running.setDescription("Pemberitahuan tetap saat TIMER MAXDIS menghitung mundur.");
        running.setShowBadge(false);
        NotificationChannel alarm = new NotificationChannel(
                CHANNEL_ALARM, "Timer selesai", NotificationManager.IMPORTANCE_HIGH);
        alarm.setDescription("Pemberitahuan ketika waktu lorong selesai.");
        alarm.enableVibration(true);
        nm.createNotificationChannel(running);
        nm.createNotificationChannel(alarm);
    }

    @Override public void onCreate() {
        super.onCreate();
        createChannels(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_RESTORE : intent.getAction();
        if (!TimerState.isActive(this) && !TimerState.isRunning(this) && !TimerState.isFinished(this)) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        startInForeground(buildNotification(TimerState.isFinished(this)));

        if (ACTION_NEXT.equals(action)) {
            handler.removeCallbacks(ticker);
            stopAlarm();
            cancelTimerAlarm(this);
            TimerState.advance(this);
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (ACTION_FINISH.equals(action)) {
            if (TimerState.isRunning(this)) {
                completeTimer();
            } else if (TimerState.isFinished(this)) {
                startAlarm();
                updateNotification(true);
                handler.removeCallbacks(ticker);
                handler.postDelayed(ticker, 3000L);
            }
            return START_STICKY;
        }

        if (TimerState.isRunning(this)) {
            long remaining = TimerState.endEpoch(this) - System.currentTimeMillis();
            if (remaining <= 0) {
                completeTimer();
            } else {
                scheduleCompletionAlarm(this, TimerState.endEpoch(this));
                stopAlarm();
                handler.removeCallbacks(ticker);
                handler.post(ticker);
                updateNotification(false);
            }
        } else if (TimerState.isFinished(this)) {
            handler.removeCallbacks(ticker);
            startAlarm();
            updateNotification(true);
            handler.postDelayed(ticker, 3000L);
        } else {
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private void startInForeground(Notification notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void completeTimer() {
        if (!TimerState.isRunning(this)) return;
        handler.removeCallbacks(ticker);
        cancelTimerAlarm(this);
        TimerState.markFinished(this);
        startAlarm();
        updateNotification(true);
        handler.postDelayed(ticker, 3000L);
    }

    private void startAlarm() {
        if (alarmPlayer != null && alarmPlayer.isPlaying()) return;
        stopAlarm();
        try {
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            alarmPlayer = MediaPlayer.create(this, R.raw.notifikasi, attributes, 0);
            if (alarmPlayer == null) throw new IllegalStateException("notifikasi.mp3 tidak dapat dimuat");
            alarmPlayer.setLooping(true);
            alarmPlayer.setOnErrorListener((mp, what, extra) -> {
                stopAlarm();
                return true;
            });
            alarmPlayer.start();
            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0, 350, 650}, 0));
                } else {
                    //noinspection deprecation
                    vibrator.vibrate(new long[]{0, 350, 650}, 0);
                }
            }
        } catch (Exception e) {
            android.util.Log.e("MAXDIS", "Tidak dapat memutar notifikasi.mp3", e);
            stopAlarm();
        }
    }

    private void stopAlarm() {
        try {
            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null) vibrator.cancel();
        } catch (Exception ignored) {}
        if (alarmPlayer != null) {
            try { if (alarmPlayer.isPlaying()) alarmPlayer.stop(); } catch (Exception ignored) {}
            try { alarmPlayer.release(); } catch (Exception ignored) {}
            alarmPlayer = null;
        }
    }

    private void updateNotification(boolean finished) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(finished));
    }

    private Notification buildNotification(boolean finished) {
        int index = TimerState.index(this);
        String title = "TIMER MAXDIS";
        String text;
        String channel = finished ? CHANNEL_ALARM : CHANNEL_RUNNING;
        if (finished) {
            text = TimerLogic.NAMES[index] + " selesai • Tekan LANJUT";
        } else {
            long remain = Math.max(0L, TimerState.endEpoch(this) - System.currentTimeMillis());
            text = TimerLogic.NAMES[index] + " • QTY " + TimerState.currentQty(this)
                    + " • " + TimerLogic.formatDuration((remain + 999L) / 1000L)
                    + " tersisa";
        }

        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);
        builder.setSmallIcon(R.drawable.ic_stat_timer)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(finished
                        ? text + ". Alarm akan terus berbunyi sampai tombol LANJUT ditekan."
                        : text + ". Timer tetap berjalan saat layar mati atau aplikasi ditinggalkan."))
                .setContentIntent(content)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false);

        if (finished) {
            Intent next = new Intent(this, NextActionReceiver.class);
            PendingIntent nextPi = PendingIntent.getBroadcast(this, 11, next,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            builder.addAction(R.drawable.ic_stat_timer, "LANJUT LORONG", nextPi);
            builder.setPriority(Notification.PRIORITY_HIGH);
        } else {
            builder.setPriority(Notification.PRIORITY_LOW);
        }
        return builder.build();
    }

    public static void scheduleCompletionAlarm(Context context, long endEpochMillis) {
        AlarmManager am = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = alarmPendingIntent(context);
        am.cancel(pi);
        long trigger = Math.max(System.currentTimeMillis(), endEpochMillis);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi);
            }
        } catch (SecurityException ex) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        }
    }

    public static void cancelTimerAlarm(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        if (am != null) am.cancel(alarmPendingIntent(context));
    }

    private static PendingIntent alarmPendingIntent(Context context) {
        Intent i = new Intent(context, AlarmReceiver.class);
        i.setAction("id.maxdis.timer.ALARM_DONE");
        return PendingIntent.getBroadcast(context, 101, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Intentionally keep the foreground service alive when the user swipes the Activity away.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopAlarm();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
